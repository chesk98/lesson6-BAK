$(".fade").fadeOut(4000, function() {
  $(this).slideDown(4000);
  $(this).fadeIn(4000);
  $(this).slideUp(4000);
  $(this).show(4000);
});
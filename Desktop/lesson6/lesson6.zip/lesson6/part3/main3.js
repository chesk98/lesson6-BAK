$("p").hide();
$("button").click(function() {
  $("p").show(2000);
  
});
